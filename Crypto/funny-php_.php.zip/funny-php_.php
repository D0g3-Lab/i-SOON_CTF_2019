<?php
$miwen="=Z2KqkyJnu1IKMIIHgyJDO1GBkRGCWIFWqxFSEHFXS0C/NxC80GB54mC9DQA0RGZ";

function encode($str){

	$str1=array();
	$str1=unpack("C*",$str);
	for($_0=0;$_0<count($str1);$_0++){
		$_c=$str1[$_0];
		$_=$_.$_c;
	}

	$_d=array();
	for($_1=0;$_1<strlen($_);$_1++){
		$_d[$_1]=substr($_,$_1,1);		
		$_e=ord($_d[$_1])+$_1;
		$_f=chr($_e);
		$__=$__.$_f;
		if($__%100==0)
			$__=base64_encode($__);
	}
	$__=strrev(str_rot13(base64_encode($__)));

	return $__;
	
}


	
$anwser=encode($str);
print($anwser);

?>