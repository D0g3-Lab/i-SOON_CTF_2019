# -*- coding: utf-8 -*-
import gmpy2
import string
from secret import m, flag


def encrypt(m,key1,key2):
    c=''
    for i in range(len(m)):
        a = table.index(key1[i % len(key1)])
        b = table.index(key2[i % len(key2)])
        p = table.index(m[i])
        c += table[(p*a+b) % 26]
    return c


def decrypt(c,key1,key2):
    m = ''
    for i in range(len(c)):
        a = table.index(key1[i % len(key1)])
        b = table.index(key2[i % len(key2)])
        inv_a = gmpy2.invert(a, 26)
        p = table.index(c[i])
        m += table[(inv_a*((p-b+26) % 26)) % 26]
    return m


if __name__ == "__main__":
    table = string.ascii_lowercase
    key1 = '????'
    key2 = '????'

    assert ("CTF{" + key1 + '-' + key2 + "}" == flag)

    for key in key1:
        assert gmpy2.gcd(table.index(key), 26) == 1

    c = encrypt(m, key1, key2)
    print "Ciphertext: " + c
    # Ciphertext: ltpflwfkqnyfmbjbchqnadkaykyhgpzaezjfrfkdonetcvcrkaaronhdnvghmyzwshrhefgqjfbrphqmgvglgvlfonzzqngxqfsessrhphupnvlfxsxotmzccnqfvmfdlhujqvezonbhsnsgykffzmbhefxtrrfjqsxywnolschammigsuetynevesboxmolrirbzhnhtynalodsgnyhxahlrifjqyijphgaqrlrclrhpattjcegcviubmztdvysstskrqelgfzjmjqhjmnmqkhcumftngxltgebfossacnvscaosixddmzcuqdyxciqaugqzoatgxnhmvczlrrfezzhlqalpogfejetmqfthtojfxeuxmqmushcbwsqtmdfdovtulzhlqccnobdshiqascgqxuyjwegbqdfrogrrgxhwfqpqqayooeoxanrunprzsigmatptaxjfavmaaqazoirructbmffenahsjxyahuajtomfsfnavgbcvsysxsjqkggjvlfreqoxaqlwflfzmipxyqiqaxfgoskauczogsdbaurejccjfoxgnknehlpnkyyjauowhymqfsceosbrydlkofyesrdzakazkbrzcxyastfsnymcarhjmtvgvbtrueoxmlljvhfljqgcmqtcrzjjscrahdtgfozonxvrigqunlrcrilnngvkfsmzwroxmlljvhfljqgcmhlgczvztenqnmpcvocuafoxmqpkkfclpsgafetgcfoezqoajpveuegywqoajitraltjssjedczjvessyevjmsycykypjijensqocbfftehhgltcqocpjijepscsfogjwhvncnbemzospqolhgedcfzsyijwnaoubzjymfnaynpnqogepzdlvgcooftfwsksytpdymjoxcdnnugwysrvhnhtynalodsgnyhlvsacyspwweuxanvusssseetnyfncvkvetsozqtbetyysixyagcgkoky