import AES256
key = '000102030405060708090a0b0c0d0e0f' #test key
msg = 'This_is_not_flag_This_is_a_demo' #test msg
print("msg: ", msg)

cipher = AES256.encrypt(msg,key,"ECB","")
print ("cipher: ",cipher)

plain = AES256.decrypt(cipher,key,"ECB","")
print ("plain: ",end="")
AES256.plain_to_ascii(plain)